package edu.uw.tcss450.ui;

/**
 * Duy Nguyen
 * TCSS 450
 * Lab 1 Assignment
 */

import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

import edu.uw.tcss450.R;
import edu.uw.tcss450.databinding.FragmentRegisterBinding;

/**
 * The register fragment class allows the user to register their login info.
 * This class contains 5 text fields, First name, Last name, Email Address, Password and Confirmation
 * of password.
 */
public class RegisterFragment extends Fragment {


     Button register;               // A button for register.
     EditText edFirstName;          // A text field for user's first name
     EditText edLastName;           // A text field for user's last name
     EditText edEmail;              // A text field for user's email address
     EditText edPassword;           // A text field for user's password
     EditText edConfirmPassword;    // A text field to confirm the user's password

     private FragmentRegisterBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentRegisterBinding.inflate(inflater, container, false);

        edFirstName = binding.FirstName;
        edLastName = binding.LastName;
        edEmail = binding.Email;
        edPassword = binding.Password;
        edConfirmPassword = binding.RetypePassword;
        register = binding.Register;

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkValidRegister();
            }
        });

        new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                Navigation.findNavController(getView()).navigate(RegisterFragmentDirections.actionRegisterFragmentToSignInFragment());
            }
        };

        return binding.getRoot();
    }

    /**
     * A private helper method to check all the requirements that the user must complete before
     * creating a sign in account.
     */
    private void checkValidRegister() {
        String firstName = edFirstName.getText().toString();
        String lastName = edLastName.getText().toString();
        String checkEmail = edEmail.getText().toString();
        String checkPassword = edPassword.getText().toString();
        String confirmPass = edConfirmPassword.getText().toString();

        if (firstName.isEmpty() || firstName.equals(lastName)) {
            edFirstName.setError("This field cannot be empty and must not be the same as the last name");
        } else if (lastName.isEmpty() || lastName.equals(firstName)) {
            edLastName.setError("This field cannot be empty and must not be the same as the first name");
        } else if (checkEmail.isEmpty() || !checkEmail.contains("@")) {
            edEmail.setError("Please enter an appropriate email address");
        } else if (checkPassword.length() < 6 || !checkPassword.equals(confirmPass)) {
            edPassword.setError("Your password must match and must be at least 6 characters in length");
        } else {
            RegisterFragmentDirections.ActionRegisterFragmentToSuccessFragment directions = RegisterFragmentDirections.actionRegisterFragmentToSuccessFragment(checkEmail,"");
            Navigation.findNavController(getView()).navigate(directions);
        }
    }

}